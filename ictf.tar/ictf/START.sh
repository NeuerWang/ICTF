#/bin/sh

python StandardCTF.py -i -c config/standard_mafia2007.ini

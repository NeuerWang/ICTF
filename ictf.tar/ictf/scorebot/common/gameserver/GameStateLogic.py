class GameStateLogic:

	def handleBotMessage(self,msg,dispatcher):
		assert(False)

	def setup(self,bot_server):
		assert(False)

class ServiceInfo:

	def __init__(self,id,name,script,timeout,offscore,defscore):
		self.id = id
		self.name = name
		self.script = script
		self.timeout = timeout
		self.offscore = offscore
		self.defscore = defscore

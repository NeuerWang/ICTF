class TeamInfo:

	def __init__(self,id,name,host,cidr):
		self.id = id
		self.name = name
		self.host = host
		self.cidr = cidr

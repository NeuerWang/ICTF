class ConfigHandler:

	def canHandle(self,section):
		assert(False)

	def parse(self,cip,section,config):
		assert(False)

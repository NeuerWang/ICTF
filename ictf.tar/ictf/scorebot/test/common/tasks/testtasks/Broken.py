#!/usr/bin/env python
import sys

def main(argv):
		foo = 2/0

if __name__ == '__main__':
	main(sys.argv)

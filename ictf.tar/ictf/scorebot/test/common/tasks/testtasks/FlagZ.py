#!/usr/bin/env python
import sys

def main(argv):
	while(True):
		print "FLAG: omganotherflagbbq"
		sys.stdout.flush()

if __name__ == '__main__':
	main(sys.argv)

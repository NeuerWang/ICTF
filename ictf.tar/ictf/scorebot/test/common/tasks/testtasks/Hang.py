#!/usr/bin/env python
import sys

def main(argv):
	while(True):
		foo = 2+2

if __name__ == '__main__':
	main(sys.argv)

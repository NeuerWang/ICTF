#!/usr/bin/python -u
import sys

def main(argv):
	print "A"*1024
	print "B"*1024

	while(True):
		foo = 2+2

if __name__ == '__main__':
	main(sys.argv)

#!/usr/bin/env python

import sys


def main(argv):
	ip = argv[1]
	print "\nFLAG: foobarbaz"

if __name__ == '__main__':
	main(sys.argv)

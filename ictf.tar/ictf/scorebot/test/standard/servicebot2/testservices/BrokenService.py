#!/usr/bin/env python

import sys
print 32/0

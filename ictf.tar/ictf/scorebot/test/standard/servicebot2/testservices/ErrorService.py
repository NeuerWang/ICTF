#!/usr/bin/env python

import sys

print "ERROR: An Error"
